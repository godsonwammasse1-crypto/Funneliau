function openScreen(screenId) {
  const screens = document.querySelectorAll('.screen');
  screens.forEach(screen => screen.classList.remove('active'));

  document.getElementById(screenId).classList.add('active');
}

document.addEventListener('DOMContentLoaded', () => {

  // Fonction pour afficher un écran spécifique
  window.openScreen = function(screenId) {
    const screens = document.querySelectorAll('.screen');
    screens.forEach(s => s.classList.remove('active')); // cacher tous les écrans
    const target = document.getElementById(screenId);
    if(target){
      target.classList.add('active'); // montrer l'écran ciblé
      target.scrollIntoView({ behavior: 'smooth' }); // animation fluide
    }
  }

  // Tous les boutons "Retour à l’accueil"
  const retourBtns = document.querySelectorAll('.back'); // ici on prend la classe back
  retourBtns.forEach(btn => {
    btn.addEventListener('click', () => openScreen('home'));
  });

});
